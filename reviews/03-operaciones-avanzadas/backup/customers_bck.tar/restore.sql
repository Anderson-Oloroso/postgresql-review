--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE campus_store;
--
-- Name: campus_store; Type: DATABASE; Schema: -; Owner: ilark
--

CREATE DATABASE campus_store WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Guatemala.1252';


ALTER DATABASE campus_store OWNER TO ilark;

\unrestrict (null)
\connect campus_store
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: ilark
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    first_name character varying(30),
    last_name character varying(30),
    email character varying(100)
);


ALTER TABLE public.customers OWNER TO ilark;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: ilark
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO ilark;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ilark
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: ilark
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: ilark
--

COPY public.customers (id, first_name, last_name, email) FROM stdin;
\.
COPY public.customers (id, first_name, last_name, email) FROM '$$PATH$$/5023.dat';

--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ilark
--

SELECT pg_catalog.setval('public.customers_id_seq', 15, true);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: ilark
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: customers u_email; Type: CONSTRAINT; Schema: public; Owner: ilark
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT u_email UNIQUE (email);


--
-- PostgreSQL database dump complete
--

